import React from 'react';
import { Link } from 'react-router-dom';
import { Layers, LogIn } from 'lucide-react';
import { useAuthStore } from '../../store/auth';

export function Header() {
  const user = useAuthStore((state) => state.user);

  return (
    <header className="border-b border-gray-200 bg-white">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          <div className="flex items-center">
            <Link to="/" className="flex items-center space-x-2">
              <Layers className="h-8 w-8 text-indigo-600" />
              <span className="text-xl font-bold text-gray-900">Pureskills</span>
            </Link>
          </div>

          <nav className="flex items-center space-x-8">
            <Link to="/courses" className="text-gray-600 hover:text-gray-900">
              Courses
            </Link>
            {user ? (
              <Link
                to="/dashboard"
                className="inline-flex items-center justify-center rounded-md bg-indigo-600 px-4 py-2 text-sm font-medium text-white hover:bg-indigo-700"
              >
                Dashboard
              </Link>
            ) : (
              <Link
                to="/login"
                className="inline-flex items-center justify-center space-x-2 rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50"
              >
                <LogIn className="h-4 w-4" />
                <span>Sign In</span>
              </Link>
            )}
          </nav>
        </div>
      </div>
    </header>
  );
}