import React from 'react';
import { Link } from 'react-router-dom';
import { Layers } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-white border-t border-gray-200">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="py-12">
          <div className="flex items-center justify-center space-x-2">
            <Layers className="h-8 w-8 text-indigo-600" />
            <span className="text-xl font-bold text-gray-900">Pureskills</span>
          </div>
          
          <nav className="mt-8 flex justify-center space-x-8">
            <Link to="/about" className="text-gray-600 hover:text-gray-900">
              About
            </Link>
            <Link to="/contact" className="text-gray-600 hover:text-gray-900">
              Contact
            </Link>
            <Link to="/privacy" className="text-gray-600 hover:text-gray-900">
              Privacy
            </Link>
            <Link to="/terms" className="text-gray-600 hover:text-gray-900">
              Terms
            </Link>
          </nav>
          
          <p className="mt-8 text-center text-gray-500">
            © {new Date().getFullYear()} Pureskills. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}